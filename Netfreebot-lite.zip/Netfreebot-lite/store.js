const fs = require('fs')
const chalk = require('chalk')

global.owner = [
['522218451057', true], 
['17057023790'], 
['17057023790']
]

global.wm = '© Netfreebot-lite'
global.prefa = '.'
global.session = 'session'
global.vs = '2.0.0'
global.author = 'zam'
global.lolkey = 'jdv'

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Actualización '${__filename}'`))
delete require.cache[file]
require(file)
})